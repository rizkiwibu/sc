global.owner = [
  ['62813173864'],
  ['6281212181641'],
  ['6285878836361', 'https://t.me/Ikystoreofficial', 'irfanwibu88@gmail.com', true]
]; // Put your number here
global.mods = ['6285878836361']; // Moderator
global.prems = ['6285878836361']; // Premium
// YANG ATAS ITU UBAH JADI NOMOR LU
// & YG BAWAH INI, NOMOR,NAMA,EMAIL LU
global.fsizedoc = '45000000000'; // default 10TB
global.fpagedoc = '19';
global.numberbot = '6285878836361';
global.nomerown = '6285878836361';
global.namedoc = 'IKYBOT WHATSAPP OFFICIAL';
global.nameowner = 'https://t.me/Ikystoreofficial',
global.bisnis = '6285878836361@s.whatsapp.net'; //Ganti pakai nomor akun bisnis kalian jika Ingin fake nya work
global.mail = 'irfanwibu88@gmail.com';
global.nomorown = '6285878836361'; 
global.dana = '-';
global.pulsa = '-';
global.ovo = '-';
global.credit = '*⁉️Buy Script??, Contact my number*\nwa.me/6285878836361'
global.namebot = 'IKYBOT WHATSAPP OFFICIAL';
global.sgc = "https://chat.whatsapp.com/KIcqnzY4NJMHXPTz8Xopvd";
global.sourceUrl = "https://instagram.com/ikykunnnn";
global.sig = 'IKYBOT WHATSAPP OFFICIAL';
global.swa = 'wa.me/6285878836361';
global.gif = ' '; //Ini buat gif yang di menu
global.thumb = 'https://telegra.ph/file/85f06f26c3f39a00eb814.jpg';
global.allmenu = 'https://telegra.ph/file/2d0f467f5dfc4944d9884.jpg';
global.statuspanel = 'https://telegra.ph/file/85f06f26c3f39a00eb814.jpg';
global.version = '10.2.1';
global.wm = 'IKYBOT WHATSAPP OFFICIAL';
global.watermark = wm;
global.lann = 'p8ADYJib';
global.xzn = 'Ikyskizo'
global.maelyn = 'lilith12'
global.lolkey = 'GataDios'
global.wm2 = 'IKYBOT WHATSAPP OFFICIAL';
global.wm3 = namebot;
global.danied = '*Command tidak dapat di akses!!!*'; 
global.wm4 = namebot;
global.fla = 'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=';
global.wait = '*[💬] L O A D I N G . . .*';
global.eror = `━━━━[ *IKYBOT WHATSAPP OFFICIAL* ]━━━━
*•STATUS:*  ERROR ❌
━━━━━━━━━━━━━━━━━
*Namebot:* ${namebot}
*Owner:* ${nameowner}
━━━━━━━━━━━━━━━━━
*💬 hubungi owner kami*
wa.me/${nomorown}`
global.done = `${credit}`
global.salah = 'Salah\n';
global.web = global.sourceUrl;
global.APIs = { 
};
global.APIKeys = { 
};
// GANTI WM DISINI
global.packname = 'IKYBOT WHATSAPP OFFICIAL';
global.author = ``;

/* PANEL SETTING */
/*
GAK PUNYA PANEL KOSONGIN AJA 
*/
global.domain = 'https://server.botwaaa.web.id';
global.apikey = 'ptla_X5rALzKPrhkGOnnxSzpjzAOmWsLmpF6ptJ8B9KbMAg4';
global.panel = `*📮 OPEN PANEL BY IKY STORE*

_*IKY STORE* Menyediakan panel hosting khusus bot WhatsApp murah, aman, terpercaya ✅_

┏━━ *「  PAKET BIASA 」*
┃ ❖ *1GB/3.000*
┃ ❖ *2 GB/4.000*
┃ ❖ *3 GB/5.000*
┃ ❖ *4 GB/6.000*
┃ ❖ *5 GB/7.000*
┃ ❖ *6 GB/8.000*
┃ ❖ *7 GB/9.000*
┃ ❖ *8 GB/10.000*
┃ ❖ *UNLIMITED/16.000*
┗━━━━━━━━━━━━━━━━━━┅

┏━━ *「  PAKET PM2 CLOSE 」*
┃ ❖ *1GB/2.000*
┃ ❖ *2 GB/4.000*
┃ ❖ *3 GB/6.000*
┃ ❖ *4 GB/8.000*
┃ ❖ *5 GB/10.000*
┃ ❖ *UNLIMITED/15.000*
┗━━━━━━━━━━━━━━━━━━┅

*[ ⚡ KEUNTUNGAN* ]

_[ ✅ ] Panel di buat khusus untuk bot WhatsApp_

_[ ✅ ] Panel di Jaga dan di rawat kualitasnya agar dapat hasil yang memuaskan_

_[ ✅ ] Privasi Panel selalu di jaga sebaik mungkin dan tidak membuka jasa *Admin Panel* demi mengurangi jumlah pencurian file_

_[ ✅ ] Mendapatkan garansi 2 jika panel mangalami masalah/website mati_



*Minat Hubungi nomor ini:*
wa.me/6281212181641`;



global.multiplier = 45;
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      sampah: '🗑',
      armor: '🥼',
      sword: '⚔️',
      kayu: '🪵',
      batu: '🪨',
      string: '🕸️',
      kuda: '🐎',
      kucing: '🐈' ,
      anjing: '🐕',
      petFood: '🍖',
      gold: '👑',
      emerald: '💚'
    };
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string));
    if (!results.length) return '';
    else return emot[results[0][0]];
  }
};

/*Yang Ini Jangan Di Ubah Yah Kak*/
let fs = require('fs');