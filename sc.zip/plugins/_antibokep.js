const uploadImage = require("../lib/uploadImage.js");
const fetch = require('node-fetch');

async function before(m, { isBotAdmin, isAdmin }) {
  if (m.isBaileys && m.fromMe) return true;
  let chat = global.db.data.chats[m.chat];
  let sender = global.db.data.chats[m.sender];
  let hapus = m.key.participant;
  let bang = m.key.id;
  const isFoto = m.mtype;
  
  if (isFoto === "imageMessage") {
    if (isAdmin || !isBotAdmin) {
      return true;
    } else {
      const media = await m.download();
      const url = await uploadImage(media);
      const response = await fetch(`https://api.itsrose.life/image/nsfwCheck?url=${url}&apikey=${global.rose}`);
      const json = await response.json();
      if (json.result.is_nsfw){ 
        m.reply(`*[❌ NSFW DETECT ]*\nGambar kamu mengandung hal-hal terlarang. 3 kali kirim bokep akan otomatis di-kick.\n\n*Probabiity:* ${json.result.rating}`);
        return this.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }});
      } else m.reply("*[ AMAN ✅ ]*\nGambar kamu tidak mengandung hal aneh-aneh")
    }
    return true;
  }
  return true;
}

module.exports = { before };