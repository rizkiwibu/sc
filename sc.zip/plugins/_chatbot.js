const fetch = require('node-fetch');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    throw `*Contoh:* ${usedPrefix + command} Halo kak`;
  }
    try {
      const simiResponse = await fetch(`https://api.lolhuman.xyz/api/simi?apikey=Akiraa&text=${text}&badword=false`);
      const simiData = await simiResponse.json();
      let hasil = ` *[ 💬 ]* ${simiData.result}`
     m.reply(hasil)
    } catch (e) {
      throw "Maaf, aku tidak mengerti";
    }
};

handler.command = handler.help = ['simi', 'chatbot'];
handler.tags = ['info'];
handler.premium = false;

module.exports = handler;