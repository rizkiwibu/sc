/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = m => m

handler.before = async function (m) {
    let user = global.db.data.users[m.sender]                              
    if (new Date() - user.premiumTime > 0) {
            user.premiumTime = 0
            user.premium = false
        }
    }

module.exports = handler