/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const axios = require("axios");

async function before(m, conn) {
  if (m.isBaileys && m.fromMe) return;
  let chat = global.db.data.chats[m.chat];
  if (
    m.text.startsWith(".") ||
    m.text.startsWith("#") ||
    m.text.startsWith("!") ||
    m.text.startsWith("/") ||
    m.text.startsWith("\\/")
  )
    return;
  if (chat.simi && !chat.isBanned && m.isGroup && m.text) {
    try {
      const simiResponse = await axios.get(`https://api.lolhuman.xyz/api/simi?apikey=${global.lolkey}&text=${m.text}&badword=false`);
      const simiData = simiResponse.data;
      let hasil = ` 💬 ${simiData.result}`
     m.reply(hasil)
    } catch (e) {
      throw "Maaf, aku tidak mengerti";
    }
  }
  return;
}

module.exports = { before };