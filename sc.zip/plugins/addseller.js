/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let syaii = async(m, { conn, text}) => {
if (!text) throw `Siapa yang Ingin dijadikan reseller panel?`
if (global.db.data.users[text +"@s.whatsapp.net"].seller === true) throw "dia sudah menjadi reseller"
global.db.data.users[text +"@s.whatsapp.net"].seller = true
m.reply("sukees menjadikan dia sebagai reseller panel")
}
syaii.command = syaii.help = ["addseller"]
syaii.tags = ["cpanel"]
syaii.owner = true
module.exports = syaii