let fetch = require('node-fetch')
let handler = async (m, { conn, args, text, command, usedPrefix}) => {
  if (!text) return m.reply(`Example: ${usedPrefix}${command} hai sayangku`)
  let res = `https://api.yanzbotz.my.id/api/tts/aoi?query=${text}`
  conn.sendFile(m.chat, res, `aoi.mp3`, '', m, true);
}
handler.help = ['aiaoi <teks>']
handler.tags = ['ai']
handler.command = /^aiaoi|aoi$/i
handler.limit = true
handler.premium = false
//export default handler

module.exports = handler;