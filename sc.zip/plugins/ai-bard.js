/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require ("node-fetch")
const uploadImage = require ("../lib/uploadImage.js")
const Bardie = require ("../scrape/bardie.js")
const bard = new Bardie();
let handler = async (m, {
	conn,
	args,
	usedPrefix,
	command
}) => {
	let text
	if (args.length >= 1) {
		text = args.slice(0).join(" ")
	} else if (m.quoted && m.quoted.text) {
		text = m.quoted.text
	} else return m.reply("Input Teks")
	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || ""
	await m.reply(wait)
	if (!mime) {
		try {
			let res = await GoogleBard(text)
			await m.reply(res.content);
			
				} catch (e) {
					await m.reply(eror)
		}
	} else {
		let media = await q.download()
		let isTele = /image\/(png|jpe?g)/.test(mime)
		let link = await uploadImage(media)
		let res = await GoogleBardImg(text, link)
		await m.reply(res.content);
	}
  }
handler.help = ["bard"]
handler.tags = ["ai"]
handler.command = /^(bard)$/i
handler.premium = true
module.exports = handler

async function GoogleBard(query) {
	return await bard.question({
		ask: query
	});
};

async function GoogleBardImg(query, url) {
	return await bard.questionWithImage({
		ask: query,
		image: url
	});
};