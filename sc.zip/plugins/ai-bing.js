/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Masukkan Prompt\n*Contoh:* ${usedPrefix + command} wanita dengan rambut hitam menggunakan kaos hitam bertuliskan "Akiraa" yang sedang duduk di meja komputer dengan layar komputer menyala dengan gambar wallpaper codingan`;
    m.reply('Mohon tunggu...');
    try {
        let Bing = await (await axios.get(`https://kiicodeofficial.my.id/api/ai/bingcreate?q=${text}&apikey=DjL3e6zerE`)).data;
        for (let i of Bing.data) {
            conn.sendMessage(m.chat, { image: { url: i }, caption: `*Bing Ai Generate Image*\n\n*Prompt:* ${text}` }, { quoted: m });
        }
    } catch (e) {
        m.reply("Bing Image down, please try again later...");
    }
}

handler.command = handler.help = ["bingimg"];
handler.tags = ["ai"];
handler.premium = true;
module.exports = handler;