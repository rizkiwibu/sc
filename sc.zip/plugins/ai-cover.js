/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require ('node-fetch');
const fs = require('fs');


let handler = async (m, { conn, command, args }) => {

  const apiUrl = 'https://api.itsrose.life/sovits/inference_voice';

 const voiceIDs = [
  "adele",
  "among_us",
  "amr_diab",
  "amy_winehouse",
  "andrew_tate",
  "angry_cat",
  "antimage_dota",
  "ariana_grande",
  "assala_nasri",
  "aw_aw_cat",
  "bad_bunny",
  "bang_chan",
  "barbie_margot",
  "barry_white",
  "bart_simpson_en",
  "bart_simpson_spa",
  "batman_christian_bale",
  "batman_kevin_conroy",
  "beyonce",
  "bill_clinton",
  "bill_kaulitz",
  "billie_eilish",
  "bjork",
  "bob_marley",
  "brazilian_lord_x",
  "britney_spears",
  "bruno_mars",
  "butters_stotch",
  "captain_america",
  "car_burnout",
  "car_horn",
  "cardi_b",
  "central_cee",
  "chainsaw",
  "chapolin_colorado",
  "chicken",
  "chorao",
  "chris_evans",
  "cogumelando",
  "counter_strike_radio",
  "cristiano_ronaldo",
  "crying_baby",
  "darth_vader",
  "darwin_watterson_tr",
  "diego",
  "dinho",
  "doc_hudson",
  "doctor_strange",
  "doja_cat",
  "dolores_umbridge",
  "donald_duck",
  "donald_trump",
  "dota_crystal_maiden",
  "dota_puck",
  "dota_rubick",
  "dota_shadow_fiend",
  "dota_slardar",
  "dota_sniper",
  "dota_sven",
  "drake",
  "dwight_eisenhower",
  "eazy_e",
  "ed_sheeran",
  "elissa",
  "ella_fitzgerald",
  "elon_musk",
  "elsa",
  "elton_john",
  "elvis_presley",
  "eminem",
  "eren_yeager",
  "eric_cartman",
  "erkin_koray",
  "ezreal_lol",
  "frank_sinatra",
  "franklin_roosevelt",
  "freddie_mercury",
  "fredo",
  "gabriel_diniz",
  "garen_lol",
  "giveon",
  "goku_dragonball",
  "gollum",
  "goofy",
  "gumball_en",
  "gumball_spa",
  "haerin",
  "hailey_bieber",
  "half_life_2_zombie",
  "han_jisung",
  "harry_styles",
  "heesung_hypen",
  "homer_simpson",
  "hugh_jackman",
  "hulk",
  "hulk_hogan",
  "hwang_hyunjin"
  ]
  
    if (!args[0]) {
    return conn.reply(m.chat, `Mana model suara/link youtube nya? Contoh:\n\n*.aicover yae_miko https://www.youtube.com/watch?v=Ci_zad39Uhw*\n\n*[ LIST MODEL ]*\n`  + voiceIDs.map((v, index) =>  index + 1 + ". " + v).join("\n"), m);
  }
    
  const requestBody = {
    youtube_url: args[0],
    voice_id: args[1],
    watermark: false
  };
    m.reply(wait)

 
    try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      body: JSON.stringify(requestBody),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `${global.rose}`
      }
    });

    if (!response.ok) {
      throw new Error(`API request failed with status: ${response.status}`);
    }

    const responseBody = await response.json();

    if (responseBody.status === true) {
  // Download the video
  const videoUrl = responseBody.result.video;
  const videoResponse = await fetch(videoUrl);
  const videoBuffer = await videoResponse.buffer();

  // Save the video as a temporary file
  const videoFilename = 'output.mp4'; // Use the appropriate video format and extension
  fs.writeFileSync(videoFilename, videoBuffer);

  // Use ffmpeg to extract audio from the video
  const { exec } = require('child_process');
  exec(`ffmpeg -i ${videoFilename} -q:a 0 -map a audio.mp3`, (error, stdout, stderr) => {
    if (error) {
      console.error(error);
      conn.reply(m.chat, 'Error convert audio nya.', m);
      return;
    }

    // Send the audio file to the user
    conn.sendMessage(m.chat, {audio: { url: "audio.mp3"}, mimetype: "audio/mpeg"},{quoted: m})
    // Delete temporary files
    fs.unlinkSync(videoFilename);
    fs.unlinkSync('audio.mp3');
  });
};

} catch (error) {
 throw error 
  }
};
handler.command = handler.help = ['aicover'];
handler.tags = ['ai'];
handler.limit = true;

module.exports = handler;