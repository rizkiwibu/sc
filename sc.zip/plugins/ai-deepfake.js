const axios = require('axios');
const uploadImage = require('../lib/uploadImage.js');

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";
  
  if (!/image\/(jpe?g|png)/.test(mime)) {
    throw `Reply/upload an image with the command ${usedPrefix + command} <style>
*Example:* ${usedPrefix + command} cutie_16`;
  }
  
  if (!text) {
    throw `Style is undefined`;
  }
  
  const configs = {
    init_image: await uploadImage(await q.download()),
    style: text
  };
  
  await conn.sendMessage(
    m.chat,
    {
      text: `*Please wait...*
Style: *${text}*`,
    },
    { quoted: m }
  );
  
  try {
    const { data } = await axios.request({
      baseURL: "https://api.itsrose.life",
      url: "/deep_fake/video",
      method: "POST",
      params: { apikey: global.rose },
      data: { ...configs },
    });
    
    const { status, message, styles, result } = data;
    
    if (!status) {
      let listStyles = styles.map((index, a) => `${index + 1}: ${a}`);
      return m.reply(message + `\n• List deepfake styles:\n${listStyles}`);
    }
    
    await conn.sendMessage(m.chat, { video: { url: result["video"] } }, { quoted: m });
  } catch (error) {
    if (error.response) {
      const { status, message, styles } = error.response.data;
      if (!status) {
        let listStyles = styles.map((index, a) => `${index + 1}: ${a}\n`);
        return m.reply(message + `\n• List deepfake styles:\n${listStyles}`);
      }
      throw message;
    } else {
      throw "An error occurred while processing the request.";
    }
  }
};

handler.command = handler.help = ["deepfake"];
handler.tags = ["ai"];
module.exports = handler;