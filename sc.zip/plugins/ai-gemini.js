/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require("node-fetch");
const uploadImage = require("../lib/uploadFile.js");

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let text;
  if (args.length >= 1) {
    text = args.slice(0).join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
  } else return m.reply("*Example:* .gemini halo");

  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  await m.reply(wait);

  if (!mime) {
    try {
      let res = await GeminiChat(text);
      await m.reply(res);
    } catch (e) {
      await m.reply(eror);
    }
  } else {
    let media = await q.download();
    let isTele = /image\/(png|jpe?g)/.test(mime);
    let link = await uploadImage(media);
    let res = await GeminiImage(text, link);
    await m.reply(res);
  }
};

handler.help = ["gemini"];
handler.tags = ["ai"];
handler.command = /^(gemini)$/i;
handler.premium = true;

module.exports = handler;

async function GeminiChat(query) {
  let Gemini = await (
    await fetch(
      `https://api.yanzbotz.my.id/api/ai/gemini?query=${query}&apiKey=AkiraaBotz`
    )
  ).json();
  return Gemini.result;
}

async function GeminiImage(query, url) {
  let Gemini = await (
    await fetch(
      `https://api.yanzbotz.my.id/api/ai/gemini-image?url=${url}&query=${query}&apiKey=AkiraaBotz`
    )
  ).json();
  return Gemini.result;
}