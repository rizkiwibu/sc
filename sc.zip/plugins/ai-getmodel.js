const axios = require("axios");

let handler = async (m, { conn, text }) => {
  const server = `1.frieren\n2.rose\n3.lisa\n4.jisoo`;
  if (!text) return m.reply(`${server}\n\n*Contoh*: getmodel rose`);
  if (!(text === 'rose' || text === 'frieren' || text === 'lisa' || text === 'jisoo')) return m.reply('Masukkan nama server yang benar ‼️');
  
  let { key } = await conn.sendMessage(m.chat, { text: '*Sedang Memuat...*' }, { quoted: m });
  
  try {
    let api = `https://api.itsrose.life/image/diffusion/get_all_models?server_name=${text}&apikey=${global.rose}`;
    let { data } = await axios.get(api);

    if (!data.status) {
      m.reply(data.message);
      return;
    }

    let result = data.result;

    let response = `*- ControlNET Models:*\n${result.controlnet_models.map(model => '◦ ' + model).join('\n')}\n\n*- Models:*\n${result.models.map(model => '◦ ' + model).join('\n')}\n\n*- Lora Models:*\n${result.lora_models.map(model => '◦ ' + model).join('\n')}\n\n*- Samplers:*\n${result.samplers.map(model => '◦ ' + model).join('\n')}`;

    await conn.sendMessage(m.chat, { text: response, contextInfo: { stanzaId: key, participant: m.sender } });
  } catch (e) {
    console.log(e);
    m.reply("Terjadi kesalahan saat memuat data");
  }
};

handler.help = ['getmodel'];
handler.tags = ['ai'];
handler.command = /^getmodel$/i;

handler.register = true;
handler.limit = false;

module.exports = handler;