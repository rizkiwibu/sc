/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fetch = require("node-fetch")
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
try {
if (!text) return m.reply(`⁉️ Masukan Prompt\n*Example:* ${usedPrefix + command} 1girl, white hair\n\nTambahkan parameter setmodel untuk mengatur model\n*Example:* ${usedPrefix + command} setmodel`)

const [subcommand, options] = args
let model = db.data.googleai

switch(subcommand) {
case "setmodel":
if (!options) throw "Masukan model\nList model: Cinematic,Photographic,Anime,Manga,Digital Art,Pixel art,Fantasy art,Neonpunk,3D Model"
db.data.googleai = options
m.reply(`✅ Sukses set model menjadi *${options}*`)
break;
}
m.reply(wait)
let a = await( await fetch(`https://api.yanzbotz.my.id/api/text2img/google-text2img?prompt=${text}&model=${model}&apiKey=AkiraaBotz`)).json()
let caption = `*Google ai generate image*

*Prompt:* ${text}
*model:* ${model}
`
conn.sendFile(m.chat, a.result.img1, null, caption, m)
} catch (e) {
m.reply("*COMMAND ERROR ❌*")
}
}
handler.help = ["googleai Prompt"]
handler.tags = ["ai"] 
handler.command = ["googleai"]
module.exports = handler