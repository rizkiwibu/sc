/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require('node-fetch')
const axios = require('axios')
const { cai } = require('../scrape/api.js')

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukkan Pertanyaan\n*Contoh:* ${usedPrefix + command} My name is Hutao ><`
m.reply(wait)
  try {
    let tanya = await cai(text, "hutao")
let a = await fetch(`https://api.lolhuman.xyz/api/translate/auto/ja?apikey=Akiraa&text=${tanya.output}`)
    let result = await a.json()
    const { data } = await axios.post("https://api.arifzyn.biz.id/ai/vits", {
      text: result.result.translated,
      model_id: 1,
      lang: "ja"
    })
    const media = Buffer.from(data.result, "base64")
    conn.sendFile(m.chat, media, '', '', m, true, {
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          title: '👻 AI HUTAO',
          mediaType: 1,
          body: 'voice ai hutao',
          thumbnailUrl: 'https://pbs.twimg.com/media/E-IHYr2WYAc2swi.jpg:large',
          renderLargerThumbnail: true,
          sourceUrl: null 
        }
      }
    })
  } catch (err) {
    m.reply(`Gunakan bahasa yang sopan ` + err)
  }
}

handler.command = handler.help = ["hutao", "aihutao"]
handler.tags = ["ai"]
module.exports = handler