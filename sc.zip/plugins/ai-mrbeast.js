/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require('node-fetch')
const { cai } = require('../scrape/api.js')
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukkan Pertanyaan\n*Contoh:* ${usedPrefix + command} My name is Jimmy`
try {
let a = await fetch(`https://api.lolhuman.xyz/api/translate/auto/en?apikey=${global.lolkey}&text=${text}`)
let result = await a.json()
let tanya = await cai(result.result.translated,"mr beast")
  let beast = `https://api.yanzbotz.my.id/api/tts/mrbeast?query=${tanya.output}&apiKey=AkiraaBotz`
  conn.sendFile(m.chat, beast, '', '', m, true, {
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: 'VOICE MR BEAST',
     mediaType: 1,
        body: 'voice ai Mr. Beast',
        thumbnailUrl: 'https://telegra.ph/file/3abb987c5878aa1287f90.jpg',
        renderLargerThumbnail: true,
        sourceUrl: null 
      }
    }
  })
} catch (err) {
m.reply(`Gunakan bahasa yang sopan`)
}
}

handler.command = handler.help = ["mrbeast", "vn-beast"]
handler.tags = ["ai"]
module.exports = handler