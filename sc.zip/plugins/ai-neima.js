let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `Masukan prompt\n*Example:* ${usedPrefix + command} a girl white hair`
m.reply(wait)
let buffer = `https://api.yanzbotz.my.id/api/text2img/neima?prompt=${text}`
conn.sendFile(m.chat, buffer, '', `*Prompt:* ${text}\n*Model:* ${command}`, m)
}
handler.help = ["neima"]
handler.tags = ["ai"]
handler.command = ["neima"]
module.exports = handler