const axios = require('axios');

let previousMessages = []; // Variabel untuk menyimpan pesan-pesan sebelumnya

const handler = async (m, { text, usedPrefix, command }) => {
global.pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
  if (!text) throw `*Example:* ${usedPrefix + command} halo`;

  let name = conn.getName(m.sender);
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

  let messages = [{
    role: 'user',
    content: text
  }];

  let ini = (await axios.post("https://skizo.tech/api/openai?apikey=ikyskizo", {
    messages,
    system: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah akiraa, dan kamu adalah Junior. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat ceria, bikin obrolan singkat dengan max 300 kata, jangan gunakan kata "aku bantu hari ini" pada setiap obrolan,kamu adalah akiraa bukan ai`
  })).data;

  let itu = `https://api.itsrose.life/tools/tts?text=${ini.result}&voice_id=elon_musk&apikey=${global.rose}`

  await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
  conn.sendFile(m.chat, itu, '', null, m, true, { contextInfo: { externalAdReply: {  title: '[ 👤 A I  V O I C E ]', body: 'ai voice with name akiraa ', thumbnailUrl: pp, sourceUrl: '', mediaType: 1, showAdAttribution: true, renderLargerThumbnail: true }}});

  previousMessages = messages; // Menyimpan pesan-pesan sebelumnya untuk penggunaan selanjutnya
};

handler.command = handler.help = ['aivoice'];
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;