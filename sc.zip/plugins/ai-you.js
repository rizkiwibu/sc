let syaii = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw "*Example:* " + usedPrefix + command + " halo";
  m.reply(wait);
  let a = await Func.fetchJson(
    "https://api.yanzbotz.my.id/api/ai/you?query=" +
      text +
      "&apiKey=AkiraaBotz",
  );
  let hasil = a.result.url
    .map((u, index) => `${index + 1}. ${u.url}`)
    .join("\n\n");
  m.reply(a.result.response + "\n\n" + "*Sumber:*" + "\n" + hasil);
};

syaii.help = syaii.command = ["youai"];
module.exports = syaii;

