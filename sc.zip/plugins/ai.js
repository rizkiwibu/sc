/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const axios = require("axios");

let handler = async (m, { conn, isOwner, usedPrefix, command, text }) => {
  if (!text) return m.reply("Mau nanya apa sama gambar itu?");

  const prompt = `nama kamu ikybot`; // isi prompt lu

  const requestData = { content: text, user: m.sender, prompt: prompt };

  const quoted = m && (m.quoted || m);

  try {
    let response;

    if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post("https://luminai.my.id", requestData)).data.result;

    await m.reply(`${response}`);
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ["ai"];
handler.tags = ["ai"];
handler.command = /^(ai)$/i;

module.exports = handler;