const { cai } = require("../scrape/api.js")
const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `*Example:* ${usedPrefix + comamd} hi boochi`;
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
  let tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=${global.lolkey}&query=bocchi+icon`)
let p = await tio.json()
let url = p.result.Math.floor(Math.random() * p.result.length)
  await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
  
  let hasil = await cai(text, "Hitori gotou")
await conn.sendFile(m.chat, url, '', hasil.message, m)
  
  previousMessages = messages;
};

handler.command = handler.help = ['aibocchi'];
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;