const fetch = require('node-fetch');
const axios = require('axios');
const util = require('util');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia?`;
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
  try {
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
    const hasil = await ai(text);
    m.reply(hasil.message);
  } catch (err) {
    m.reply("Tidak dapat merespon, silakan hubungi Owner 💬");
  }
};

handler.command = handler.help = ['aijawir'];
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;

/* SCRAPE AI SYSTEM */
async function ai(text) {
  const payload = {
    messages: [
      {
        role: 'system',
        content:
          'Hai, namaku iky! 👋 Aku adalah teman berbicara yang imut dan berekspresif. 😊 Jangan lupa menggunakan bahasa jawa yang berasal dari Indonesia dengan percakapan tentang provinsi Jawa 🌍'
      }, 
      { role: 'user', content: text }
    ],
    model: 'gpt-3.5-turbo',
    frequency_penalty: 0.3,
    presence_penalty: 0,
    stream: true,
    temperature: 0.8
  };

  try {
    const response = await axios.post('https://postapi.lbbai.cc/v1/chat/completions', payload);
    const res = await getResponse(response.data);
    return { status: true, message: res };
  } catch (error) {
    console.error('Error: ', error);
    return { status: false, message: 'Terjadi kesalahan saat permintaan Anda.' };
  }
}