const fetch = require('node-fetch');
const { generateWAMessageFromContent, prepareWAMessageMedia } = require('@adiwajshing/baileys');
const { proto } = require('@adiwajshing/baileys');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let response = await fetch("https://api.jikan.moe/v4/seasons/now?filter=tv");
  let data = await response.json();
  
  // Ambil data anime dengan detail
  let animeList = await Promise.all(data.data.map(async anime => {
    return {
      imageUrl: anime.images.jpg.large_image_url,
      title: anime.title,
      genres: anime.genres,
      type: anime.type,
      season: anime.season,
      year: anime.year,
      source: anime.source,
      episodes: anime.episodes,
      status: anime.status,
      duration: anime.duration,
      studios: anime.studios,
      rating: anime.rating,
      score: anime.score,
      popularity: anime.popularity
    };
  }));

  const createImageMessage = async (url) => {
    const { imageMessage } = await prepareWAMessageMedia({ image: { url } }, { upload: conn.waUploadToServer });
    return imageMessage;
  }

  const cards = await Promise.all(animeList.map(async (a) => {
    const imageMessage = await createImageMessage(a.imageUrl);

    // Deskripsi anime yang lebih lengkap
    const description = `*• Title:* ${a.title}
*• Genre:* *[ ${a.genres.map(g => g.name).join(", ")} ]*
*• Type:* ${a.type}
*• Season:* ${a.season} *[ ${a.year} ]*
*• Source:* ${a.source}
*• Total episodes:* ${a.episodes}
*• Status:* ${a.status}
*• Duration:* ${a.duration}
*• Studio:* *[ ${a.studios.map(s => s.name).join(", ")} ]*
*• Rating:* ${a.rating}
*• Score:* ${a.score}/10.0
*• Popularity:* ${a.popularity}`;

    return {
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: description,
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: "Powered by Jikan API",
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: '',
        hasMediaAttachment: true,
        imageMessage: imageMessage,
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Lihat Gambar",
              cta_type: "1",
              url: a.imageUrl
            })
          }
          // Tombol "SEARCH AGAIN" dihapus
        ]
      })
    };
  }));

  // Kirim pesan interaktif
  const interactiveMessage = proto.Message.InteractiveMessage.create({
    body: proto.Message.InteractiveMessage.Body.fromObject({
      text: "List of Anime Images",
    }),
    footer: proto.Message.InteractiveMessage.Footer.fromObject({
      text: "Powered by Jikan API",
    }),
    header: proto.Message.InteractiveMessage.Header.fromObject({
      title: "Anime Carousel",
      hasMediaAttachment: false,
    }),
    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
      cards: cards,
    }),
  });

  const messageContent = proto.Message.fromObject({
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage,
      },
    },
  });

  const msgs = await generateWAMessageFromContent(m.chat, messageContent, {
    userJid: conn.user.jid,
    quoted: m,
    upload: conn.waUploadToServer,
  });

  await conn.relayMessage(m.chat, msgs.message, {
    messageId: msgs.key.id,
  });
};

handler.help = ["animeupdate"];
handler.tags = ["anime"];
handler.command = ["animeupdate"];
module.exports = handler;