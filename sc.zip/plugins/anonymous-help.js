let handler = async (m, { conn }) => {
let anu = `*[ A N O N Y M O U S   C H A T ]*

Berikut adalah penjelasan cara menggunakan anonymous chat dengan perintah ".start," ".leave," dan ".next":

1. *.Start (Memulai Sesi Anonymous Chat):**
   - Ketik "start" atau perintah yang sesuai pada platform anonymous chat yang Anda gunakan. Ini akan memulai sesi obrolan anonim dengan seseorang secara acak.

2. *.Leave (Keluar dari Sesi Anonymous Chat):**
   - Jika Anda ingin keluar dari sesi anonymous chat, cukup ketik "leave" atau perintah serupa yang ditentukan pada platform tersebut. Ini akan mengakhiri obrolan dan Anda akan keluar dari sesi tersebut.

3. *.Next (Mencari Orang Selanjutnya):**
   - Jika Anda ingin mengobrol dengan orang lain atau beralih ke obrolan anonim dengan seseorang yang berbeda, ketik "next" atau perintah serupa yang sesuai pada platform tersebut. Ini akan mengarahkan Anda ke obrolan anonim dengan orang lain secara acak.`

m.reply(anu)
}
handler.command = handler.help = ['anonymous']
handler.tags = ['anonymous']
module.exports = handler