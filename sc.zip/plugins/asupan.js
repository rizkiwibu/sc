/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const axios = require("axios");

let handler = async (m, { conn }) => {
  try {
    const apiUrl = "https://api--v1-shoti.vercel.app/api/v1/get";
    const apiKey = "$shoti-1hg812ukl6qb3ph7ro8";

    const { data } = await axios.post(apiUrl, {
      apikey: apiKey,
    });

    const result = data.data;
    const caption = `
*Random cewek video*
*Title:* ${result.title}
*Rank:* ${result._shoti_rank}
*Region:* ${result.region}
*Duration:* ${result.duration}

*USER INFO*
*Name:* ${result.user.nickname}
*ID:* ${result.user.userID}
    `;

    conn.sendMessage(m.chat, {
      video: { url: result.url },
      gifPlayback: true,
      caption: caption,
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, "Terjadi kesalahan saat mengambil data", m);
  }
};

handler.help = ["asupan"];
handler.tags = ["internet"];
handler.command = ["asupan"];

module.exports = handler;