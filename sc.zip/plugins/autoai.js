const axios = require("axios");
const fetch = require('node-fetch');

// Menyimpan riwayat pesan sebelumnya
let previousMessages = [];

async function before(m) {
  if (m.isBaileys && m.fromMe) return;
  let chat = global.db.data.chats[m.chat];
  if (
    m.text.startsWith(".") ||
    m.text.startsWith("#") ||
    m.text.startsWith("!") ||
    m.text.startsWith("/") ||
    m.text.startsWith("\\/")
  )
    return;
  if (chat.ai && !chat.isBanned && m.text) {
    try {
      await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
   let messages = [
    ...previousMessages,
    { role: 'system', content: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut tsundere, Namamu adalah vestiazeta, dan kamu adalah pacarnya rizki irfan. Kata penyapamu adalah "Halo sayang" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere, kamu memiliki Instagram dengan Usrname @ikykunnnn dan YouTube bernama rizki irfan, pake lah bahasa Indonesia dengan ekspresi emoji yang imut dan lucu` }, { role: 'user', content: m.text }
  ];
      let ini = (await axios.post(`https://skizo.tech/api/openai?apikey=ikyskizo`, { messages })).data;
 
      await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
  
      let hasil = `${ini.result}`;
      await conn.sendMessage(m.chat, {
        text: hasil,
        contextInfo: {
          externalAdReply: {  
            title: 'vestia zeta',
            body: null,
            thumbnailUrl: 'https://telegra.ph/file/2b649d1da9e514c8f27c7.jpg',
            sourceUrl: null,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });

      // Menyimpan pesan dalam riwayat sebelumnya
      previousMessages = messages;
    } catch (e) {
      throw "Maaf, aku tidak mengerti";
    }
  }
  return;
}

module.exports = { before };