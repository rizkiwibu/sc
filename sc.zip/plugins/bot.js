/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let { sticker5 } = require ('../lib/sticker.js')
let handler = async (m, {conn}) => {
let P = 'https://telegra.ph/file/bc1d35f557b8f8886d6df.jpg'
let stiker = await sticker5(P, false, global.packname, global.author)
    if (stiker) return conn.sendFile(m.chat, stiker, 'Quotly.webp', '', m)
}
handler.customPrefix = /^(bot|akiraa)$/i
handler.command = new RegExp()
module.exports = handler