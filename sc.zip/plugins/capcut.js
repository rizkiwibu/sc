const { downloadCapcut } = require('../scrape/api');

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `Masukkan URL!\n\ncontoh:\n${usedPrefix + command} https://www.capcut.com/t/Zs8F2jgx7`;
  
  try {
    m.reply('*Mohon tunggu..*');
    const url = args[0];
    const get = await downloadCapcut(url);
    conn.sendFile(m.chat, 'https://ssscapcut.com' + get.originalVideoUrl, '', get.title + '\n\n' + get.description, m);
  } catch (e) {
    console.log(e);
    if (m.sender) {
      conn.reply(m.chat, `_*Terjadi kesalahan!*_`, m);
    }
  }
};

handler.help = ['capcut'];
handler.command = /^(capcut|capcutdl|cpctdl)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.private = false;

module.exports = handler;