let handler = async (m, {conn}) => {
let premium = global.db.data.users[m.sender].premium
if (premium == true)  {
conn.reply(m.chat, ' kamu Sekarang masih user Premium!!', m)
} else conn.reply(m.chat, 'Kamu bukan user premium',m)
} 
handler.command = /^(cekprem)$/i
module.exports = handler