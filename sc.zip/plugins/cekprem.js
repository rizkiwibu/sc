let handler = async (m, {conn, command}) => {
switch (command) {
case 'cekpremium':
let user = global.db.data.users[m.sender]
if (user.premium) {
conn.reply(m.chat, 'Kamu masih Premium ✅', m)
} else conn.reply(m.chat, 'kamu bukan user premium\nPerpanjang premium hubungi owne', m)
break
  }
}
handler.command = /^cekpremium$/i
module.exports = handler