/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Contoh:* ${usedPrefix + command} yae miko`;
  m.reply("Mohon tunggu...");
  try {
    let response = await fetch(`https://api.lolhuman.xyz/api/genshin/${text}?apikey=${global.lolkey}`);
    let result = await response.json();
    if (result.status !== 200) return m.reply(result.message);
    let hasil = `*====[ INFORMASI KARAKTER GENSHIN ] ====*
*Nama:* ${result.result.title}
*Deskripsi:* ${result.result.intro}
*Atribut:* ${result.result.attr}`;
    await conn.sendFile(m.chat, result.result.cover1, '', hasil, m);
conn.sendFile(m.chat, result.result.cv[0].audio[0], '', '', m, true, {
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: result.result.title.toUpperCase(),
     mediaType: 1,
        body: 'voice Actor JP: ' + result.result.cv[0].name,
        thumbnailUrl: result.result.cover,
        renderLargerThumbnail: true,
        sourceUrl: null 
      }
    }
  })
  } catch (e) {
    m.reply("❌ Gagal mengambil informasi karakter tersebut");
  }
};

handler.help = ["charagi"];
handler.tags = ["anime", "internet", "info"];
handler.command = ["charagi"];
module.exports = handler;