/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/
const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = Object.freeze({
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  });
  var replacer = [];
  xStr.map((v, i) => replacer.push({
    original: v,
    convert: yStr[style].split('')[i]
  }));
  var str = text.toLowerCase().split('');
  var output = [];
  str.map(v => {
    const find = replacer.find(x => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

const handler = async (m, { conn, text, participants }) => {
  // Mendapatkan nama grup
  let gc = await conn.groupMetadata(m.chat);

  let teks = await Styles('Tunggu sebentar sedang kloning group: ' + gc.subject);
  conn.reply(m.chat, teks, m);

  try {
    // Membuat grup baru dan mengkloning nama grup asli
    let grup = await conn.groupCreate(gc.subject, [m.sender]);
    let id = grup.id; // ID grup klon
    let pp = await conn.getProfilePicture(m.chat); // Foto profil grup

    // Menonaktifkan pesan selamat datang (agar tidak spam)
    conn.toggleWelcome(id, false);

    await conn.delay(2000); // Delay 2 detik

    // Mengkloning deskripsi grup asli
    conn.groupUpdateDescription(id, gc.desc);

    // Mengkloning foto profil grup
    conn.updateProfilePicture(id, { url: pp });

    // Menambahkan semua anggota ke grup klon
    for (let idny of participants) {
      conn.groupAdd(id, [`${idny.id.split('@')[0]}` +  '@s.whatsapp.net']);
    }

    conn.reply(m.chat, 'Sukses mengkloning grup: ' + gc.subject, m);
  } catch (e) {
    console.log(e);
    conn.reply(m.chat, 'Terjadi kesalahan: ' + e, m);
  }
};

handler.help = ['clonegrup'];
handler.tags = ['owner'];
handler.command = /^(clon|klon(ing|grup|gc)?)$/;
handler.owner = true;
handler.admin = true;

module.exports = handler;