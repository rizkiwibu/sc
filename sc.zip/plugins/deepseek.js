/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const axios = require("axios");

  if (!text) throw "Masukan Pertanyaan nya 📝";

  let { data } = await axios.post("https://ai.clauodflare.workers.dev/chat", {
    "model": "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b",
    "messages": [{
      "role": "user",
      "content": text
    }]
  }).catch(e => e.response);

  if (!data.success) throw JSON.stringify(data, null, 2);

  let response = data.data.response.split("</think>").pop().trim();
  m.reply(response);
};

handler.help = ["deepseek"];
handler.tags = ["ai"];
handler.command = ["deepseek"];
module.exports = handler;