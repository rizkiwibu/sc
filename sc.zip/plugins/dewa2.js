let handler = async (m, { conn, text }) => {
if (!text) throw `Tag salah satu yang mau jadi dewa di ikybot`
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
conn.reply(m.chat, `Sukses jadi dewa ` + text, m, { mentions: [who] })
global.db.data.users[who].money = 9999999999999999999
global.db.data.users[who].atm = 9999999999999999999
global.db.data.users[who].balance = 9999999999999999999
global.db.data.users[who].limit = 9999999999999999999
global.db.data.users[who].level = 9999999999999999999
global.db.data.users[who].exp = 9999999999999999999
global.db.data.users[who].sampah = 9999999999999999999
global.db.data.users[who].potion = 9999999999999999999
global.db.data.users[who].common = 9999999999999999999
global.db.data.users[who].uncommon = 9999999999999999999
global.db.data.users[who].mythic = 9999999999999999999
global.db.data.users[who].legendary = 9999999999999999999
global.db.data.users[who].potion =  999999999999999999
}
handler.command = /^(dewa2)$/i
handler.owner = true

module.exports = handler