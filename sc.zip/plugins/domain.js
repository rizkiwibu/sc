/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require('node-fetch')

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
const domainConfig = [
   {
    zone: "caa31829ad4ab46b60a877d8872320b9",
    apitoken: "Qhfz4VHBlXSkuXaSQwI5FK-KyMHH4L0h7GsR5uhv",
    tld: "riw.my.id"
  },
  {
    zone: "12d87b9e875a600b52296ffd2c8ad405",
    apitoken: "0451471bd91c35dc673be7bb976ed0a7",
    tld: "ikystoree.my.id"
    }
  ]
  
  // Assuming "m" and "text" are defined before this code snippet
const contoh = "contoh: *.domain 1|host|ip*\n\nList:\n" + domainConfig.map((v, index) => ((++index) + ". " + v.tld)).join('\n');
if (!text) return m.reply(contoh);

const parts = text.split("|");
if (parts.length < 3) return m.reply(contoh); // Check if all parts are available

const part0 = parseInt(parts[0]);
const part1 = parts[1].trim();
const part2 = parts[2].trim();

if (isNaN(part0) || part0 < 1 || part0 > domainConfig.length) {
  return m.reply("Invalid index. Please provide a valid number between 1 and " + domainConfig.length);
}

const config = domainConfig[part0 - 1]; // Adjusting the index to 0-based

// Check if the "host" and "ip" parts are not empty
if (!part1 || !part2) {
  return m.reply("Please provide a valid host and ip");
}

try {
  let json = await createSubDomain(config.zone, config.apitoken, config.tld, part1, part2);
  throw json
  /*
  const caption = `🔍 *[ HASIL ]*

🆔 *ID:* ${v.id || 'Tidak diketahui'}
🗺️ *Zone ID:* ${v.zone_id || 'Tidak diketahui'}
🏷️ *Zone Name:* ${v.zone_name || 'Tidak diketahui'}
📛 *Name:* ${v.name || 'Tidak diketahui'}
💡 *Type:* ${v.type || 'Tidak diketahui'}
🌐 *Content:* ${v.content || 'Tidak diketahui'}
🛡️ *Proxiable:* ${v.proxiable || 'Tidak diketahui'}
🛡️ *Proxied:* ${v.proxied || 'Tidak diketahui'}
⏳ *TTL:* ${v.ttl || 'Tidak diketahui'}
🔒 *Locked:* ${v.locked || 'Tidak diketahui'}
📝 *Meta Auto Added:* ${v.meta.auto_added || 'Tidak diketahui'}
📱 *Managed by Apps:* ${v.meta.managed_by_apps || 'Tidak diketahui'}
📱 *Managed by Argo Tunnel:* ${v.meta.managed_by_argo_tunnel || 'Tidak diketahui'}
📜 *Source:* ${v.meta.source || 'Tidak diketahui'}
💬 *Comment:* ${v.comment || 'Tidak diketahui'}
🏷️ *Tags:* ${v.tags.length === 0 ? 'Tidak ada tag' : v.tags.join(', ')}
⏰ *Created On:* ${v.created_on || 'Tidak diketahui'}
⏰ *Modified On:* ${v.modified_on || 'Tidak diketahui'}`
await conn.reply(m.chat, caption, m)
*/
} catch (error) {
  throw error;
  // Handle the error or send an error message back to the user
}

}
handler.help = ['domain']
handler.tags = ['owner']
handler.command = ['domain']
handler.owner = true

module.exports = handler;

async function createSubDomain(zone, apitoken, tld, host, ip) {
  const headers = {
    Authorization: "Bearer " + apitoken,
    "Content-Type": "application/json",
  };

  const data = {
    type: "A",
    name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tld}`,
    content: ip.replace(/[^0-9.]/gi, ""),
    ttl: 3600,
    priority: 10,
    proxied: true,
  };

  const response = await fetch(`https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(data),
  });

  const res = await response.json();
  return res;
}