/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fs = require('fs')
let handler = async (m, { conn }) => {
let name = conn.getName(m.sender)
let numberowner = global.numberowner
let anu = `Hallo Kak 👋 ${name}
Silahkan donasi agar bot tetap aktif

╭─『  Donasi • E-money  』
├ Dana : *Chat owner*
├ Ovo : *Chat owner*
├ *Qris : Chat Owner*
╰───

Berapapun donasi kalian akan sangat berarti

☞ Info selengkapnya : wa.me/${nomorown}

*❒ Keuntungan Donasi Bagi Bot* 
☞ Buat sewa VPS supaya bot bisa aktif 24 jam
☞ Buat beli limit apikey fitur
☞ Supaya bot terus update & aktif

*❒ Keuntungan Donasi Bagi Para Donasi*
☞ Bisa dapat exp
☞ Bisa dapat limit
☞ Bisa dapat money

*[ Developer iky bot ]*`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'S U P P O R T',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/a631996f92016ae1b2f37.png',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['donasi', 'donate']
handler.tags = ['xp', 'info']
handler.command = /^(donasi|donate)$/i

module.exports = handler