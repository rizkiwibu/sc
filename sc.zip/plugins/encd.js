/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const JavaScriptObfuscator = require('javascript-obfuscator')

let handler = async (m, { conn, text }) => {
if (!text) throw `[!] Masukan textnya`
let res = JavaScriptObfuscator.obfuscate(text)
let hasil =`/*Sc Iky Bot By rizki
*Whatsapp: wa.me/6283842839555
*Credit: © AkiraaBot 2023-2024
*/
${res.getObfuscatedCode()}`
conn.reply(m.chat, hasil, m)
}
handler.help = ['encrypt']
handler.tags = ['tools']
handler.command = /^encd(rypt)?$/i

module.exports = handler