
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Example:* ${usedPrefix + command} https://www.facebook.com/100063980835309/videos/395936539473273/?app=fbl`
m.reply(wait)
try {
let a = await FbDownload(text)
await conn.sendMessage(m.chat, {video: {url: a.links["Download Low Quality"]},caption: a.title},{quoted: m})
} catch (e) {
m.reply("Facebook Error")
}
}
handler.command = handler.help = ["fb","fbdl","facebook"]
handler.tags = ["downloader"]
module.exports = handler

async function FbDownload(vid_url) {
    try {
        const data = {
            url: vid_url
        };
        const searchParams = new URLSearchParams();
        searchParams.append('url', data.url);
        const response = await fetch('https://facebook-video-downloader.fly.dev/app/main.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: searchParams.toString(),
        });
        const responseData = await response.json();
        return responseData;
    } catch (e) {
        return null;
    }
}