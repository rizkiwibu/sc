/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const uploadFile = require('../lib/uploadFile.js');
const uploadImage = require('../lib/uploadImage.js');
const fetch = require('node-fetch');
const { generateSerpApiUrl } = require('../scrape/serpapi.js');

let handler = async (m, {
    command,
    usedPrefix,
    conn,
    text,
    args
}) => {
    let [urutan] = args;
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime) {
        let help = `*GOOGLE LENSA 🔍*
  "*Google Lens* adalah layanan penelusuran visual yang memungkinkan Anda menemukan informasi lebih lanjut tentang objek di sekitar Anda menggunakan gambar atau video"
  
*💬 Mrs akiraa:* Tidak ada media yang ditemukan. Kirimi saya gambar atau video untuk dicari menggunakan Google Lens.

*Reply/Send media yang ingin anda cari di Google lens*`;
        await conn.sendFile(m.chat, 'https://telegra.ph/file/fb02ee62a9612ae59c4b7.jpg', null, help, m);
    }

    let media = await q.download();
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link = await (isTele ? uploadImage : uploadFile)(media);
    await m.reply("🔍 Menganalisis...");

    try {
        const serpApiKey = 'd52da17da557f02e45234c11db22c4e9fe19c15d68a378e0a31f11d92b2cf562';
        const serpApiEngine = 'google_lens';
        const serpApiUrl = await generateSerpApiUrl({
            api_key: serpApiKey,
            engine: serpApiEngine,
            url: link
        });
        let visualMatches = serpApiUrl.visual_matches;

        if (!urutan) {
            await conn.sendFile(m.chat, 'https://telegra.ph/file/fb02ee62a9612ae59c4b7.jpg', null, "*GOOGLE LENSA 🔍*\nBerikut Adalah hasil terkait pertanyaanmu, ketik angka sesuai yang ada di bawah\n*Contoh:* .google-lens 1\n" + visualMatches.map((item, index) => `*${index + 1}.* ${item.title}`).join("\n"), m);
        } else if (isNaN(urutan) || urutan <= 0 || urutan > visualMatches.length) {
            await conn.sendFile(m.chat, 'https://telegra.ph/file/fb02ee62a9612ae59c4b7.jpg', null, "*GOOGLE LENSA 🔍*\nBerikut Adalah hasil terkait pertanyaanmu, ketik angka sesuai yang ada di bawah\n*Contoh:* .google-lens 1\n" + visualMatches.map((item, index) => `*${index + 1}.* ${item.title}`).join("\n"), m);
        } else {
            let selectedResult = visualMatches[urutan - 1];
            let resultCaption = `🔍 *[ HASIL GOOGLE LENS ]*\n\n` +
                `*Deskripsi:* ${selectedResult.title || 'Tidak ada'}\n` +
                `*Sumber:* ${selectedResult.source || 'Tidak ada'}\n` +
                `*Link:* ${selectedResult.link || 'Tidak ada'}\n` +
                `*Thumbnail:* ${selectedResult.thumbnail || 'Tidak ada'}\n\n`;

            await conn.sendFile(m.chat,selectedResult.thumbnail,null, resultCaption, m)
        }
    } catch (error) {
        await m.reply(error);
        await m.reply(
            "🚫 *Error:* Terjadi kesalahan saat mencari menggunakan Google Lens. Silakan coba lagi nanti."
        );
    }
};

handler.help = ["google-lens *<Nomor urut>*"];
handler.tags = ["search", "internet"];
handler.command = /^(google-lens)$/i;
handler.limit = true;

module.exports = handler;