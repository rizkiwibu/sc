var fetch = require("node-fetch");
let handler = async (m, { 
conn, 
args 
}) => {
   response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Text\nContoh : .hacker Bang syaii'
  m.reply('_Proses..._')
  var tio = `https://api.lolhuman.xyz/api/ephoto1/anonymhacker?apikey=${global.lolkey}&text=${response[0]}`
  conn.sendFile(m.chat, tio, 'loliiiii.jpg', wm, m, false)
};
handler.command = handler.help = ['hacker'];
handler.tags = ['maker'];
module.exports = handler;