const fetch = require('node-fetch');
var handler = async (m, { conn, args, usedPrefix, command }) => {
     var tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=${global.lolkey}&query=honkai`)
var p = await tio.json()
let url = p.result[Math.floor(Math.random()  *p.result.length)]
  conn.sendFile(m.chat, url, 'loliiiii.jpg', `_*🔖R A N D O M   H O N K A I*_` , m, false)
}
handler.help = ['honkai']
handler.tags = ['anime']
handler.command = /^(honkai)$/i
handler.limit = true;
module.exports = handler;