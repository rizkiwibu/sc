/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const fetch = require('node-fetch')

const getazzgptResponse = async (q, u) => {
  try {
    const response = await fetch(`https://api.azz.biz.id/api/gpt?q=${q}&user=${u}&key=global`);
    const data = await response.json();
    return data.respon;
  } catch (error) {
    console.error(error);
    return null;
  }
};

const handler = async (m, { text }) => {
  if (!text) throw 'Contoh: .iky Pesan yang ingin Anda sampaikan kepada asisten AI';

  m.reply(wait);
  
  try {
    
    const response = await getazzgptResponse(text, m.name);

    m.reply(response);
  } catch (error) {
    console.error('Error:', error);
    m.reply(eror);
  }
};

handler.help = ['iky (chatgpt iky)'];
handler.tags = ['ai'];
handler.command = /^(iky)$/i;

module.exports = handler;