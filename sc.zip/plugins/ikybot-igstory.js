/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const axios = require('axios');

let handler = async (m, { conn, text }) => {
  if (!text) {
    throw '*Example:* .igstory kemii.denpai';
  }

  let username = text.trim();

  try {
    let api = `https://api.lolhuman.xyz/api/igstory/${username}?apikey=${global.lolkey}`;
    let { data } = await axios.get(api);

    if (data.status !== 200 || data.result.length === 0) {
      throw '🐱 No Instagram story found for the given user.';
    }

    let mediaUrls = data.result;
	conn.chatRead(m.chat)
	conn.sendMessage(m.chat, {
		react: {
			text: '🕒',
			key: m.key,
		}
	})

    for (let url of mediaUrls) {
      await conn.sendFile(m.chat, url, '', '', m);
    }
  } catch (error) {
    console.log(error);
    throw '🐱 An error occurred while retrieving Instagram story.';
  }
};

handler.help = ['igstory'];
handler.tags = ['downloader'];
handler.command = /^igstory$/i;

module.exports = handler;