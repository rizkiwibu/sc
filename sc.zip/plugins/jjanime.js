/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const { ttSearch } = require('../scrape/api.js');

let handler = async (m, { conn, usedPrefix, command, text }) => {
  try {
    m.reply('Mohon tunggu...');
    let res = await ttSearch("Preset am anime");
    
    let random = Math.floor(Math.random() * res.videos.length);
    let file = res.videos[random];
    let url = 'https://tikwm.com' + file.play;
    
    conn.sendFile(m.chat, url, 'error.jpg', file.title, m);
  } catch (err) {
    m.reply('*❌ Video tidak ditemukan*');
  }
};

handler.command = handler.help = ['jjanime'];
handler.tags = ['internet'];
module.exports = handler;