/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i

let handler = async (m, { conn, text }) => {
    let [_, code] = text.match(linkRegex) || []
    if (!code) throw 'Link invalid'
    try {
        const res = await conn.groupAcceptInvite(code)
    } catch (e) {
        throw `Error`
    } finally {
        m.reply(`Berhasil join grup ${(await conn.groupGetInviteInfo(code)).id}`)
    }
}
handler.help = ['join <chat.whatsapp.com>']
handler.tags = ['info']

handler.command = /^join$/i

handler.owner = true

module.exports = handler