let fetch = require('node-fetch')
let handler = async(m, { conn, usedPrefix, text, args, command }) => {
if (!text) throw `Contoh:
${usedPrefix + command} gustixa`
let f = await fetch(`https://api.lolhuman.xyz/api/jooxplay?apikey=${global.lolkey}&query=${text}`)
let x = await f.json()
let teks = `*Result:*
*singer:* ${x.result.info.singer}
*song:* ${x.result.info.song}
*album:* ${x.result.info.album}
*date:* ${x.result.info.date}
*duration:* ${x.result.info.duration}
*duration:* ${x.result.lirik}
`
  await conn.sendFile(m.chat, x.result.image, '', teks, m)
  await conn.sendFile(m.chat, x.result.audio[0].link, '', '', m)
            
}

handler.command = handler.help = ['joox']
handler.tags = ['tools','downloader','search']
module.exports = handler