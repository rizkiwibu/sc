let uploadImage = require('../lib/uploadImage.js');

let handler = async (m, { conn, text, participants, usedPrefix , command}) => {
  let groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce).map(v => v[0]);
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";
  if (!mime) {
    return conn.reply(m.chat, `Example: reply/send image with caption *${usedPrefix + command}*`, m);
  }
  let image = await uploadImage(await q.download());
  conn.reply(m.chat, `_Mengirim pesan broadcast ke ${groups.length} grup_`, m);
  for (let id of groups) {
    let participantIds = participants.map(a => a.id);
    await conn.sendFile(id, image, null, text + '\n' + readMore + '[ AKIRAA BROADCAST]', fkontak).catch(_ => _);
  }
  m.reply(`Selesai Broadcast ${groups.length} Group`);
}

handler.help = ['jpm'].map(v => v + ' <teks>');
handler.tags = ['owner'];
handler.command = /^(jpm)$/i;
handler.owner = true;
module.exports = handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

const randomID = length => require('crypto').randomBytes(Math.ceil(length * .5)).toString('hex').slice(0, length);