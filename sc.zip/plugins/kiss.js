const fetch = require('node-fetch');
const { MessageType } = require('@adiwajshing/baileys');
const { sticker5 } = require('../lib/sticker.js');

const handler = async (m, { conn, args, usedPrefix, command }) => {
  let who;
  if (m.isGroup) {
    who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
  } else {
    who = m.chat;
  }
  if (!who) {
    throw `🍟 Tag atau sebutkan seseorang\nContoh: ${usedPrefix + command} @tag`;
  }

  const rki = await fetch('https://api.waifu.pics/sfw/kiss');
  if (!rki.ok) {
    throw await rki.text();
  }
  const jkis = await rki.json();
  const url = jkis;
await conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c4ee2b5726d4a12ab1d07.jpg' }, caption:   `@${m.sender.split('@')[0]} Mencium @${who.split('@')[0]}`, mentions: [m.sender, who] }, { quoted: m })
};

handler.help = ['kiss @tag'];
handler.tags = ['fun'];
handler.command = /^(kiss)$/i;
handler.diamond = true;
handler.group = true;

module.exports = handler;