/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const WebSocket = require("ws");
const fs = require("fs");

let handler = async (m, { conn, args, usedPrefix, command }) => {
	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || q.mediaType || "";
	if (/audio|video/.test(mime)) {
		let media = await q.download?.();
		m.reply(wait);
		let wss = "wss://yanzbotz-waifu-yanzbotz.hf.space/queue/join";

		function generateRandomLetters(length) {
			let result = "";
			const alphabetLength = 26;

			for (let i = 0; i < length; i++) {
				const randomValue = Math.floor(Math.random() * alphabetLength);
				const randomLetter = String.fromCharCode(
					"a".charCodeAt(0) + randomValue,
				);
				result += randomLetter;
			}

			return result;
		}

		/*

Scraper by YanzBotz 
Claim gw ewe luh

*/

		const kobo = async (audio) => {
			return new Promise(async (resolve, reject) => {
				let name =
					Math.floor(Math.random() * 100000000000000000) +
					(await generateRandomLetters()) +
					".mp4";
				let result = {};
				let send_has_payload = {
					fn_index: 2,
					session_hash: "xyuk2cf684b",
				};
				let send_data_payload = {
					fn_index: 2,
					data: [
						{
							data: "data:audio/mpeg;base64," + audio.toString("base64"),
							name: name,
						},
						args[0],
						"pm",
						0.6,
						false,
						"",
						"en-US-AnaNeural-Female",
					],
					event_data: null,
					session_hash: "xyuk2cf684b",
				};
				const ws = new WebSocket(wss);
				ws.onopen = function () {
					console.log("Connected to websocket");
				};

				ws.onmessage = async function (event) {
					let message = JSON.parse(event.data);

					switch (message.msg) {
						case "send_hash":
							ws.send(JSON.stringify(send_has_payload));
							break;

						case "send_data":
							console.log("Processing your audio....");
							ws.send(JSON.stringify(send_data_payload));
							break;
						case "process_completed":
							result.base64 =
								"https://yanzbotz-waifu-yanzbotz.hf.space/file=" +
								message.output.data[1].name;
							break;
					}
				};

				ws.onclose = function (event) {
					if (event.code === 1000) {
						console.log("Process completed️");
					} else {
						msg.reply("Err : WebSocket Connection Error:\n");
					}
					resolve(result);
				};
			});
		};
		let abcd = await kobo(await media);

		conn.sendFile(m.chat, abcd.base64, "", "", m);
	} else
		throw `Reply audio with caption ${usedPrefix + command} <path>
	
Harap perhatikan penggunaan path (path 0 - 12)
- biasanya untuk suara berat path-nya 10-12
- untuk perempuan path-nya adalah 0
	
Contoh : ${usedPrefix + command} 0`;
};
handler.command = ['kobovoice'];
handler.help = ['kobovoice [aivoice hololive]'];
handler.tags = ['Ａ Ｉ ＶＩＯＣＥ ＣＯＶＥＲ'];

module.exports = handler;