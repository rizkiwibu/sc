

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.komikus = conn.komikus ? conn.komikus : {};
if (!text) throw `*Example:* ${usedPrefix + command} konosuba`
m.reply(wait)
let search = await (await fetch(`https://skizo.tech/api/v2/komiks?q=${text}&apikey=${global.xzn}`)).json()
let hasil = search.result.map((v, index) => `${index + 1}.*${v.title.toUpperCase()}*\n*Genre:* ${v.genre.map((v, index) => v).join(", ") || "Tidak di ketahui"}\n*Type:* ${v.type}\n*Score:* ${v.score}`).join("\n\n") 
conn.sendFile(m.chat, search.result[0].img, null, hasil, m)
conn.komikus = search.result
}
handler.help = ["komikus"]
handler.tags = ["anime"]
handler.command = ["komikus"]
module.exports = handler