let fetch = require ('node-fetch')

let handler = async(m, { conn, text }) => {
  if (!text) throw `Linknya Mana?\n*Example:* .komikudetail https://komiku.id/manga/naruto-konohas-story-the-steam-ninja-scrolls/`
  let res = await fetch(`https://api.ibeng.tech/api/anime/komiku-detail?url=${text}&apikey=xcAA8Vfwzv`)
  let json = await res.json()
  let { awal, terbaru, konsep_cerita, komikus, jumlah_pembaca, end } = json.data.metadata
  res = json.data.chapters.map((v) => `*Chapter:* ${v.chapter}\n*Url:* ${v.url}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`
let komiku = `• *Judul:* ${json.data.title}
• *Awal:* ${awal}
• *Terbaru:* ${terbaru}
• *Genre:* ${konsep_cerita}
• *Komikus:* ${komikus}
• *Deskripsi:* ${json.data.description}
• *Chapters*: ${res}`
  conn.reply(m.chat, komiku, m)
}
handler.help = ['komikudetail']
handler.tags = ['anime']
handler.command = /^(komikudetail)$/i
handler.limit = true

module.exports = handler