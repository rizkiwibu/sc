let fetch = require ('node-fetch')

let handler = async(m, { conn, text }) => {
  if (!text) throw `Judulnya?`
  let res = await fetch(`https://api.ibeng.tech/api/anime/komiku-search?q=${text}&apikey=xcAA8Vfwzv`)
  let json = await res.json()
  let foto = json.data[0].thumbnail
  hasil = json.data.map((v) => `*Title:* ${v.title}\n*Title_ID:* ${v.title_id}\n*Awal:* ${v.awal}\n*Terbaru:* ${v.terbaru}\n*Link:* ${v.url}\n*Deskripsi:* ${v.description}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`
    conn.sendFile(m.chat, json.data[0].thumbnail, 'anunya.jpg', hasil, m)
}
handler.help = ['komikusearch']
handler.tags = ['anime']
handler.command = /^(komikus)$/i
handler.limit = true

module.exports = handler