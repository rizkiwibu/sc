/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async (m, { conn, text, usedPrefix, command, Func }) => {
  const acrcloud = require("acrcloud");

  const acr = new acrcloud({
    host: "identify-ap-southeast-1.acrcloud.com",
    access_key: "ee1b81b47cf98cd73a0072a761558ab1",
    access_secret: "ya9OPe8onFAnNkyf9xMTK8qRyMGmsghfuHrIMmUI",
  });

  let target = m.quoted ? m.quoted : null;
  if (!target || !target.mimetype || !/audio/.test(target.mimetype)) {
    throw "⚠️ *Oops!* Harap balas pesan audio yang ingin dicari judul lagunya.";
  }

  let buffer = await target.download();
  let data = await whatmusic(buffer);

  if (!data || data.length === 0) {
    throw "❌ *Maaf!* Tidak dapat menemukan informasi lagu dari audio tersebut.";
  }

  let caption = `🎵 *Lagu Apa Ini? - Finder* 🎵\n\n`;
  for (let result of data) {
    caption += `🎶 *Judul:* ${result.title}\n`;
    caption += `🎤 *Artis:* ${result.artist}\n`;
    caption += `⏱️ *Durasi:* ${result.duration}\n`;
    caption += `🔗 *Sumber:* ${result.url.filter((x) => x).join("\n") || "Tidak ditemukan"}\n\n`;
  }

  caption += `💡 *Tips:* Kirim audio dengan kualitas yang jelas untuk hasil terbaik.`;
  m.reply(caption);
};

async function whatmusic(buffer) {
  const acrcloud = require("acrcloud");
  const acr = new acrcloud({
    host: "identify-ap-southeast-1.acrcloud.com",
    access_key: "ee1b81b47cf98cd73a0072a761558ab1",
    access_secret: "ya9OPe8onFAnNkyf9xMTK8qRyMGmsghfuHrIMmUI",
  });

  let response = await acr.identify(buffer);
  let metadata = response.metadata;
  if (!metadata || !metadata.music) return [];

  return metadata.music.map((song) => ({
    title: song.title,
    artist: song.artists.map((a) => a.name)[0],
    score: song.score,
    release: new Date(song.release_date).toLocaleDateString("id-ID"),
    duration: toTime(song.duration_ms),
    url: Object.keys(song.external_metadata)
      .map((key) =>
        key === "youtube"
          ? "https://youtu.be/" + song.external_metadata[key].vid
          : key === "deezer"
            ? "https://www.deezer.com/us/track/" +
              song.external_metadata[key].track.id
            : key === "spotify"
              ? "https://open.spotify.com/track/" +
                song.external_metadata[key].track.id
              : ""
      )
      .filter(Boolean),
  }));
}

function toTime(ms) {
  let minutes = Math.floor(ms / 60000) % 60;
  let seconds = Math.floor(ms / 1000) % 60;
  return [minutes, seconds].map((v) => v.toString().padStart(2, "0")).join(":");
}

handler.help = ["laguapaini"];
handler.tags = ["tools"];
handler.command = ["laguapaini"];
module.exports = handler;