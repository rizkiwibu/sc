/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command 
}) => {

    if (!text) throw  `*Example:* ${usedPrefix + command} jomok`
    const query = text
    const page = Math.floor(Math.random() * 10)
    const url = `https://lahelu.com/api/post/get-search?query=${query}&page=${page}`;

    try {
        const response = await fetch(url);
        const data = await response.json();   
        const random = Math.floor(Math.random() * data.postInfos.length)
       const result = data.postInfos[random];
     const message = `*====[ MEME FROM LAHELU ]====*
*Title:* ${result.title}
*Total Upvotes:* ${result.totalUpvotes}
*Total Downvotes:* ${result.totalDownvotes}
*Total Comments:* ${result.totalComments}
*Create Time:* ${new Date(result.createTime).toLocaleString()}
*Media:* ${result.media}
*Sensitive:* ${result.sensitive ? '✅' : '❌'}
*User Username:* ${result.userUsername}
*====[ MEME FROM LAHELU ]====*`;
                await conn.sendFile(m.chat, 'https://cache.lahelu.com/' + result.media, '', message, m);
    
    } catch (error) {
        console.error('Terjadi kesalahan:', error);
        conn.reply(m.chat, '❌ Terjadi kesalahan saat mengambil data', m);
    }
}

handler.command = handler.help = ['lahelu','meme']
handler.tags = ['internet'];

module.exports = handler;