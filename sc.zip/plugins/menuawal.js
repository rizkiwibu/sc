let axios = require('axios')

let handler = async (m, {
	conn
}) => {
	let user = global.db.data.users[m.sender]
	let name = conn.getName(m.sender)
	let date = new Date().toLocaleDateString('en-US', {timeZone: 'Asia/Makassar'})
	let time = new Date().toLocaleTimeString('en-US', {timeZone: 'Asia/Makassar', hour: 'numeric', minute: 'numeric', hour12: true})
	let version = require('../package.json').version
	let author = require('../package.json').author.name
	let greeting = ''

	if (new Date().getHours() >= 0 && new Date().getHours() < 4) {
		greeting = '👋 Good night'
	} else if (new Date().getHours() >= 4 && new Date().getHours() < 12) {
		greeting = '👋 Good morning'
	} else if (new Date().getHours() >= 12 && new Date().getHours() < 18) {
		greeting = '👋 Good afternoon'
	} else if (new Date().getHours() >= 18 && new Date().getHours() < 24) {
		greeting = '👋 Good evening'
	}
	let mainmenu = `Haii aku adalah *Iky Bot WhatsApp* yang dapat Anda gunakan sebagai alat untuk membuat *stiker*, mendengarkan *musik,* dan memainkan *game RPG* secara real-time.

*ikybot* juga merupakan bot yang sangat menjaga *privasi* ​​penggunanya. Data yang disimpan di database akan selamanya di simpan biar enak buat ngumpulin money,exp dan lainya tapi tenan aja tidak akan di sebar luas dan bersifat *pribadi*.

╭─ •  「 *IKY BOT BETA SC* 」
│  ◦  Clock : *${time}*
│  ◦  Date : *${new Date().toLocaleDateString()}*
│  ◦  Version : *${global.version}*
│  ◦  Author : *ikystore*
│  ◦  Prefix : *.*
│  ◦  Show all menu : *.allmenu*
│  ◦  Show about update : *.logs*
╰──── •
ʜᴀʀᴀᴘ ᴜɴᴛᴜᴋ ʙᴇʀɢᴀʙᴜɴɢ ᴄʜᴀᴛʙᴏᴛ ᴀɢᴀʀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ɪɴғᴏ ᴅᴀɴ ʙᴏɴᴜs sᴇᴛɪᴀᴘ ʜᴀʀɪɴʏᴀ *.ɢᴄʙᴏᴛ*`

	let thumbnailUrl = "https://telegra.ph/file/1c1126b42befd96ef4257.jpg"

	conn.reply(m.chat, mainmenu, m, {
		contextInfo: {
			externalAdReply: {
				title: `ikybot`,
				body: "ʜɪ, ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ iky ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ",
				thumbnailUrl: global.thumb,
				mediaType: 1,
				renderLargerThumbnail: true
			}
		}
	})
}

handler.command = /^(menu|help|bot)$/i
handler.help = ['menu']
handler.tags = ['main']
handler.limit = true
handler.register = false

module.exports = handler