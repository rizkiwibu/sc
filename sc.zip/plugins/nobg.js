/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fetch = require('node-fetch')
let uploadFile = require('../lib/uploadFile.js')

let handler = async (m, { conn, usedPrefix, command, text }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'Kirim/Reply Gambar dengan caption .removebg'
m.reply('Tunggu Sebentar...')
let media = await q.download()
let url = await uploadFile(media)
let hasil = await (await fetch(`https://skizo.tech/api/removebg?url=${url}&apikey=seika`)).buffer()
await conn.sendFile(m.chat, hasil, '', '📮Nih Hasilnya', m)
	
}
handler.help = ['nobg','removebg']
handler.tags = ['maker']
handler.command = /^(hapuslatar|removebg)$/i
handler.limit = true

module.exports = handler