const { npmstalk } = require('../scrape/api.js');

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Example:* ${usedPrefix + command} canvafy`;

  const fetch = await npmstalk('canvafy');

  const hasil = ` *± N P M   S T A L K*
° name: *${fetch.name}*
° vLatest: *${fetch.versionLatest}*
° vPublish: *${fetch.versionPublish}*
° vUpdate: *${fetch.versionUpdate}*
° PublisTime: *${fetch.PublishTime}*
`;

  await conn.sendMessage(m.chat, {
    text: hasil,
    contextInfo: {
      externalAdReply: {
        title: "Npm - Package",
        body: "",
        thumbnailUrl: "https://telegra.ph/file/2806b9ac5b9739c930a4e.jpg",
        sourceUrl: sgc,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
};

handler.command = handler.help = ["npmstalk"];
handler.tags = ["internet"];
module.exports = handler;