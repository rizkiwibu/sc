/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
ini wm gw cok jan di hapus
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async(m, { conn, text, args, participants }) => {

if (args[1] == "detik") {
          var timer = args[0] * `1000`;
        } else if (args[1] == "menit") {
          var timer = args[0] * `60000`;
        } else if (args[1] == "jam") {
          var timer = args[0] * `3600000`;
        } else if (args[1] == "hari") {
          var timer = args[0] * `86400000`;
        } else {
          return m.reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik");
        }
        m.reply(`Open time grup ${text} dimulai dari sekarang`);
        setTimeout(() => {
          var nomor = m.participant;
          const open = `*Tepat waktu* grup dibuka oleh admin\nsekarang member dapat mengirim pesan`;
          conn.groupSettingUpdate(m.chat, "not_announcement");
          m.reply(open);
        }, timer);

    }
handler.help = ['opentime']
handler.tags = ['group']
handler.command = /^(opentime)$/i

handler.group = true
handler.admin = true

module.exports = handler;