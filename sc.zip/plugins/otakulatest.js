let fetch = require ('node-fetch')
let handler = async(m, { conn }) => {
  let res = await fetch(`https://api.ibeng.tech/api/anime/otakudesu-latest?apikey=xcAA8Vfwzv`)
  let json = await res.json()
  res = json.data.map((v) => `*Title:* ${v.title}\n*Hari:* ${v.day}\n*Tanggal:* ${v.date}\n*Thumbnail:* ${v.thumb}\n*Link:* ${v.link}`).join`\n\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°\n\n`
  conn.sendFile(m.chat, json.data[0].thumbnail, 'anunya.jpg', res, m)
}
handler.help = ['otakulatest']
handler.tags = ['anime']
handler.command = /^(otakulatest)$/i
handler.limit = true
module.exports = handler