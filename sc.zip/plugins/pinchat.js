/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async (m, { conn }) => {
    if (!m.quoted) {
        return m.reply('Balas pesan yang ingin dipin!');
    }

    try {
        let quotedText = m.quoted.text || "Pesan tidak memiliki teks.";
        
        let msg = await conn.sendMessage(m.chat, {
            text: `📌 *Pesan Dipin*\n\n${quotedText}\n\n_Dipin oleh admin_`,
        });

        await conn.sendMessage(m.chat, {
            pin: msg.key, // Mem-pin pesan bot yang mengutip pesan aslinya
            type: 1,
            time: 86400, // 1 hari
        });

        m.reply("Pesan berhasil dipin selama 1 hari.");
    } catch (err) {
        console.error(err);
        m.reply("Gagal mem-pin pesan.");
    }
};

handler.help = ["pinchat"];
handler.tags = ["group"];
handler.command = ["pinchat"];
handler.group = true;
handler.admin = true;

module.exports = handler;