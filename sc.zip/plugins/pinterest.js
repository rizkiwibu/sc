/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fetch = require('node-fetch');

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  if (!args || args.length < 1) {
    throw `Masukan Pencarian!!\ncontoh: ${usedPrefix + command} Miku Nakano`;
  }

  let response = args.join(' ').split(' --');
  let query = response[0];
  let count = parseInt(response[1]);

  if (!count) {
    try {
      var tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=gataDios&query=${query}`);
      var p = await tio.json();
      let url = p.result[Math.floor(Math.random() * p.result.length)];
      conn.sendFile(m.chat, url, 'loliiiii.jpg', `_*P I N T E R E S T*_\n 🔖Hasil pencarian Dari: *${query}*\n___________________\n ${botdate}`, m);
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan perintah.', m);
    }
  } else {
    if (count > 10) {
      throw 'Jumlah gambar terlalu banyak! Maksimal 10 gambar.';
    }
    try {
      let url = `https://api.lolhuman.xyz/api/pinterest2?apikey=gataDios&query=${query}`;
      let res = await fetch(url);
      let data = await res.json();
  
      let images = data.result;
  
      for (let i = 0; i < count; i++) {
        let image = images[Math.floor(Math.random() * images.length)];
        setTimeout(() => {
          conn.sendFile(m.chat, image, '', `_*P I N T E R E S T*_\n 🔖Hasil pencarian Dari: *${query}* Gambar Ke ${i}\n___________________\n ${botdate}`, m);
        }, i * 5000); // Delay setiap pengiriman gambar selama 1 detik (1000 milidetik)
      }
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan perintah.', m);
    }
  }
};

handler.help = ['pinterest <pencarian> <jumlah>'];
handler.tags = ['tools','internet'];
handler.command = /^(pinterest|pin)$/i;

module.exports = handler;

//Create By bang syaii