/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let fetch = require('node-fetch');
let handler = async (m, { 
conn, 
args 
}) => {
try {
   let response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Text\nContoh : .pixiv Vtuber'
  m.reply('_Proses..._')
  let res = await fetch(`https://api.lolhuman.xyz/api/pixiv?apikey=gataDios&query=${response[0]}`)
let _result
try{
_result = await res.json()
} catch(e){console.log(e)}

let { status, result } = _result
if(status !=200) { m.reply('eror'); return }

let random = Math.floor(Math.random() * result.length)
let file = result[random]
  conn.sendFile(m.chat, file.image, 'pixiv.jpg', file.title, m)
} catch (err) {
m.reply("*❌ Poto Tidak di temukan*")
}
};
handler.command = handler.help = ['pixiv'];
handler.tags = ['internet'];
handler.premium = true
module.exports = handler;