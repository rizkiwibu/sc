/*
SCRIPT IKY BOT BY RIZKI IRFAN
wa.me/6285878836361
github: https://github.com/rizkiwibu
Instagram: https://instagram.com/ikykunnnn
https://youtube.com/@RIZKIIRFAN
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const yts = require('yt-search');

let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan judul';

    let src = await yts(text);
    let yt = src.videos[0];

    await conn.sendMessage(m.chat, { image: { url: yt.thumbnail }, caption: yt.title }, { quoted: m });
    return conn.sendMessage(m.chat, {
        audio: {
            url: `https://ytdl.botwaaa.web.id/yt/dl?url=${yt.url}&type=audio`
        },
        mimetype: 'audio/mpeg',
        contextInfo: {
            externalAdReply: {
                title: yt.title,
                body: 'Ikybot ytdl Api\'s',
                mediaType: 2,
                mediaUrl: yt.url,
                thumbnailUrl: yt.thumbnail,
                sourceUrl: yt.url,
                containsAutoReply: true,
                renderLargerThumbnail: true,
                showAdAttribution: false,
            }
        }
    }, { quoted: m });
}

handler.tags = ['downloader'];
handler.help = handler.command = ['play'];
handler.limit = 20
module.exports = handler;
