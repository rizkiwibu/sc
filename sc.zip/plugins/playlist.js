const yts = require ('yt-search');
const fs = require ('fs');
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*${usedPrefix + command} Music*`
    let results = await yts(text);
    let teks = results.all.map((v, i) => {
      let link = v.url;
      return `[${i + 1}] ${v.title}
↳  *_Link :_* ${v.url}
↳  *_Durasi :_* ${v.timestamp}
↳ *_Diunggah :_* ${v.ago}
↳  *_Ditonton :_* ${v.views}`
    }).join('\n\n◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦◦\n\n');
    conn.sendFile(m.chat, results.all[0].thumbnail, 'yts.jpeg', teks, m);
}
handler.help = ['playlist *<teks>*'];
handler.tags = ['search'];
handler.command = /^playlist|playlist$/i;
module.exports = handler