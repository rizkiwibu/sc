let { MessageType } = require('@adiwajshing/baileys')
let handler = async (m, { conn, text }) => { 
  if (!text) throw 'Masukkan jumlah exp yang akan diberi' 
  let who 
  if (m.isGroup) who = m.mentionedJid[0] 
  else who = m.chat 
  if (!who) throw 'Tag salah satu lah' 
  let txt = text.replace('@' + who.split`@`[0], '').trim() 
  if (isNaN(txt)) throw 'Hanya angka' 
  let xp = parseInt(txt) 
  let exp = xp 
  if (!exp >= 11000) throw `🍟 Kamu melebihi Batas premium` 
  else if (xp < 1000000) {   
     let users = global.db.data.users   
     if (!users[who]) users[who] = {}   
     if (!users[who].exp) users[who].exp = 0   
     users[who].exp = xp
     //coldown
     let cooldown = setTimeout(() => {
          conn.reply(m.chat, `Selamat @${who.split`@`[0]}. Kamu mendapatkan  ${xp}XP!`, m, {
          mentions: [who]
          }, {
          contextInfo: {
               mentionedJid: [who]
               }
          }) 
		//reset cooldown
		clearTimeout(cooldown);
       }, 100000)    
   }
}
handler.help = ['premxp @user <amount>']
handler.tags = ['premium']
handler.command = /^(premxp)$/i
handler.premium = true
handler.group = true
module.exports = handler;