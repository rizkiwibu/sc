/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
let panel  = `*==> 📮 OPEN PANEL PETRODATYL <===*
*SYAII STORE* Menyediakan Panel hosting bot WhatsApp murah dah berkualitas  ✅
*INFO PANEL:*
https://chat.whatsapp.com/IheXyXLyQu395nr6x9Ondm
*===> RAM LIST <===*
*• 📦 RAM: 1GB &CPU 100% : 1.000/BULAN*
*• 📦 RAM: 2GB &CPU 100% : 2.000/BULAN*
*• 📦 RAM: 3GB &CPU 100% : 3.000/BULAN*
*• 📦 RAM: 4GB &CPU 200% : 4.000/BULAN*
*• 📦 RAM: 5GB &CPU 300% : 5.000/BULAN*
*• 📦 RAM: 6GB &CPU 400% : 4.000/BULAN*
*• 📦 RAM: 7GB &CPU 500% : 7.000BULAN*
*• 📦 RAM: 8GB &CPU 800% : 8.000/BULAN*
*• 📦 RAM: UNLI &CPU UNLI% : 10.000/BULAN*
*===> KEUNTUNGAN  <===*
*• ✅ MEMBUAT RUNTIME BOT MENJADI AWET*
*• ✅ ANTI LEMOT*
*• ✅ MUDAH UNTUK DIGUNAKAN*
*• ✅ BERGARANSI JIKA WEBSITE MATI*
*===> CONTACT PERSON <===*
info lebih lanjut bisa hubungi nomor ini:
wa.me/6281317320864`
conn.reply(m.chat,panel, null)
}
handler.customPrefix = /^panel$/i
handler.command = new RegExp
module.exports = handler