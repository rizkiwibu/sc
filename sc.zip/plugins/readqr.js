/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const uploadImage = require ('../lib/uploadImage.js')

let handler = async (m, { conn, text, usedPrefix, command }) => {

let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw '*Barcode??*'
let img = await q.download?.()
let url = await uploadImage(img)
let json = await(await fetch(`https://api.lolhuman.xyz/api/read-qr?apikey=Akiraa&img=${url}`)).json()

await m.reply(`*here u go:* ${json.result}`)
}
handler.command = handler.help = ["readqr"]
handler.tags = ["tools"]

module.exports = handler