/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

async function before(m) {
  conn.regmail = conn.regmail ? conn.regmail : {};
  let user = global.db.data.users[m.sender];
 if (!conn.regmail[m.sender]) return 
if (isNaN(m.text)) return

  if (m.text === conn.regmail[m.sender] ) {
    user.registered = true;
    user.limit = 10000;
    user.exp = 20292929;
    let caption = `*VERIFY SUCCESS*
Selamat @${m.sender.split("@")[0]} kamu sudah mendaftar di database akiraaBot. Semua data kalian akan kami simpan dengan baik tanpa kehilangan satupun.\n\nKetik *.menu* untuk melihat semua menu`;
    m.reply(caption);
    delete conn.regmail[m.sender];
  } else {
    m.reply("Kode OTP salah, cek kembali email anda");
  }
}

module.exports = {
  before
};