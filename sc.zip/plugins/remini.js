/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

var sharp = require('sharp');
var fs = require('fs');

var handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted || !m.quoted.mimetype.startsWith('image')) {
    return m.reply(`Kirim/Balas Gambar dengan caption *${usedPrefix + command}*`);
  }

  var danz = `tmp/${Math.random().toString(36).substring(7)}.jpg`;
  var image = await conn.downloadAndSaveMediaMessage(m.quoted);
  
  var options = {
    background: 'transparent',
    flatten: true,
    quality: 100,
  };
  
  sharp(image)
    .sharpen()
    .removeAlpha()
    .toFormat('jpeg')
    .jpeg(options)
    .toFile(danz)
    .then(() => {
      conn.sendFile(m.chat, danz, '', wm, m);
      fs.unlinkSync(danz);
    })
    .catch((err) => console.error(err));
};

handler.command = handler.help = ["remini"];
handler.tags = ["maker"];

module.exports = handler;