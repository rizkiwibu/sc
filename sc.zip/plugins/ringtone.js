let fetch = require  ('node-fetch')

let handler = async (m, { conn, command, text, usedPrefix }) => {
	if (!text) throw `Mau Cari Apa?`
	let res = await fetch(`https://api.ibeng.tech/api/search/ringtone?q=${text}&apikey=xcAA8Vfwzv`)
  let result = await res.json()
  let { data, code } = result
if (code !== 200) throw `Audio tidak di temukan `
  let random = Math.floor(Math.random() * data.length)
  let file = data[random]
  let hasil = ` *R I N G T O N E*
*•Nama:* ${file.title}
*•Source:* ${file.source}
*•Url:* ${file.audio}

_sedang memuat audio..._`

let { key } = await conn.sendMessage(m.chat, {text: 'Sedang mencari ringtone...'},{quoted: fkontak})
await conn.sendMessage(m.chat, {text: `${hasil}`, edit: key},{quoted: fkontak})
conn.sendFile(m.chat, file.audio, '', null, fkontak)
}
handler.help = ['ringtone']
handler.tags = ['downloader']
handler.command = /^(ringtone)$/i
handler.limit = true

module.exports = handler